var thearray = [];
document.getElementById('submit').onclick = function (){
	NoRedditAtNightSave();
};